/*
 *  write_bmp.h
 */

void write_bmp( const char *filename, unsigned char *image, int width, int height, bool invertY );