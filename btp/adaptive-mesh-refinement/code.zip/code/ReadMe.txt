How to compile and run:

femflip2:
	$> make run
	
femflip3:
	Install GSL and zlib libraries
	$> make run

Tested on Mac and Linux systems on 1st May 2013.