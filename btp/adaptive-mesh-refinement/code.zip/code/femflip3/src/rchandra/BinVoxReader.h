/*
 *  BinVoxReader.h
 *  GridParticleFluid
 *
 *  Created by mscp on 12/4/10.
 *  Copyright 2010 さf. All rights reserved.
 *
 */

#include "macros.h"
unsigned char* loadBinVox( const char *path, FLOAT64 translate[3], FLOAT64 &scale );