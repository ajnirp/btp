#pragma once


class Grid;


class Renderer
{
		
virtual void	draw(Grid&)	 =0;


protected:

				Renderer() { }			
};

		