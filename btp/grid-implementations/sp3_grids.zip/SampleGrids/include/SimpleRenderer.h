#pragma once

#include "Renderer.h"


class SimpleRenderer : public Renderer
{
public:

				SimpleRenderer() {}
void			draw(Grid&);
};



						

