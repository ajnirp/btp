#ifndef __SPECTRUM_H
#define __SPECTRUM_H

void spectrum(double t1, double t2, int n, unsigned char* d);

#endif
